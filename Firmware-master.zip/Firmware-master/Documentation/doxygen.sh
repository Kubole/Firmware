#!/bin/sh
rm -rf html
doxygen